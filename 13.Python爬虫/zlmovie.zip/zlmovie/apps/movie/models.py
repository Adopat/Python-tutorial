from django.db import models


class MovieCategory(models.Model):
    name = models.CharField(max_length=100,verbose_name='分类名称',unique=True)


class MovieLanguage(models.Model):
    name = models.CharField(max_length=100,verbose_name='语言名称',unique=True)


class MovieCountry(models.Model):
    name = models.CharField(max_length=100, verbose_name='国家名称', unique=True)


class Movie(models.Model):
    db_movie_id = models.CharField(max_length=100,verbose_name='豆瓣电影的id',null=True)
    name = models.CharField(max_length=100,verbose_name='电影名称')
    cover = models.CharField(max_length=200,verbose_name='宣传图')
    director = models.CharField(max_length=200,verbose_name='导演',null=True)
    scriptwriter = models.CharField(max_length=200,verbose_name='编剧',null=True)
    actor = models.TextField(verbose_name='演员',null=True)
    countries = models.ManyToManyField(MovieCountry,related_name="movies",related_query_name="movies",verbose_name='制片国家/地区')
    languages = models.ManyToManyField(MovieLanguage,verbose_name='语言',related_name='movies',related_query_name='movies')
    release_date_str = models.CharField(max_length=200,verbose_name='上映日期原始文本',null=True)
    release_date = models.DateField(null=True,verbose_name='上映日期')
    duration_str = models.CharField(max_length=100,null=True,verbose_name='片长')
    duration = models.IntegerField(default=0,verbose_name='持续时间（分钟）')
    rating = models.ForeignKey("MovieRating",related_name='movie',related_query_name="movie",on_delete=models.CASCADE)
    categories = models.ManyToManyField(MovieCategory,verbose_name='电影分类')
    profile = models.TextField(verbose_name='电影简介',null=True)
    origin_url = models.CharField(max_length=200,verbose_name='原始url',null=True)


class MovieRating(models.Model):
    value = models.FloatField(default=0,verbose_name='电影评分')
    rating_people = models.IntegerField(default=0,verbose_name='评论数量')
    star5 = models.FloatField(default=0,verbose_name='五星比例')
    star4 = models.FloatField(default=0,verbose_name='四星比例')
    star3 = models.FloatField(default=0,verbose_name='三星比例')
    star2 = models.FloatField(default=0,verbose_name='二星比例')
    star1 = models.FloatField(default=0,verbose_name='一星比例')


class MovieComment(models.Model):
    db_movie_id = models.CharField(max_length=100,verbose_name='豆瓣电影的id',null=True)
    avatar = models.CharField(max_length=200,verbose_name='用户头像',null=True)
    username = models.CharField(max_length=100,verbose_name='评论作者')
    rating = models.IntegerField(default=0,verbose_name='评分')
    pub_date = models.DateField(verbose_name='发布日期')
    content = models.TextField(verbose_name='评论内容')
    movie = models.ForeignKey(Movie,related_name="comments",related_query_name='comments',on_delete=models.CASCADE)

