from django import template
from datetime import datetime

register = template.Library()

@register.filter
def star_class(value):
    value = round(value/2)
    return "bigstar%d0"%value


@register.filter
def format_date(value):
    return value.strftime("%Y-%m-%d")