from django.shortcuts import render,redirect
from django.http.response import JsonResponse
from .models import Movie,MovieCategory,MovieComment,MovieRating,MovieLanguage,MovieCountry
import re
import pymysql
from datetime import datetime
from django.views.generic import ListView
from django.db.models import Q

conn = pymysql.Connect(
    user="root",
    password="root",
    host="127.0.0.1",
    port=3306,
    database="douban_movie",
    charset="utf8"
)
cursor = conn.cursor()


def index(request):
    return redirect("list")


class MovieListView(ListView):
    model = Movie
    template_name = 'index.html'
    context_object_name = 'movies'
    paginate_by = 10
    page_kwarg = 'p'

    def get_context_data(self, **kwargs):
        context = super(MovieListView, self).get_context_data(*kwargs)
        paginator = context.get('paginator')
        page_obj = context.get('page_obj')
        pagination_data = self.get_pagination_data(paginator,page_obj,3)
        context.update(pagination_data)
        return context

    def get_pagination_data(self,paginator,page_obj,around_count=2):
        current_page = page_obj.number
        num_pages = paginator.num_pages

        left_has_more = False
        right_has_more = False

        if current_page <= around_count + 2:
            left_pages = range(1,current_page)
        else:
            left_has_more = True
            left_pages = range(current_page-around_count,current_page)

        if current_page >= num_pages - around_count - 1:
            right_pages = range(current_page+1,num_pages+1)
        else:
            right_has_more = True
            right_pages = range(current_page+1,current_page+around_count+1)

        return {
            'left_pages': left_pages,
            'right_pages': right_pages,
            'current_page': current_page,
            'left_has_more': left_has_more,
            'right_has_more': right_has_more,
            'num_pages': num_pages
        }


def detail(request,movie_id):
    movie = Movie.objects.filter(pk=movie_id).first()
    return render(request, 'detail.html',{"movie":movie})


def search(request):
    q = request.GET.get("q")
    movies = Movie.objects.filter(
        Q(name__contains=q) |
        Q(director__contains=q) |
        Q(actor__contains=q) |
        Q(scriptwriter__contains=q)
    )
    return render(request,"search.html",context={"movies":movies,"q":q})


def resave_movie(request):
    cursor.execute(
        "select db_movie_id,title,cover,director,scriptwriter,actor,category,country,lang,release_date,duration,profile,rating,rating_people,star5,star4,star3,star2,star1,origin_url from movie;")
    rows = cursor.fetchall()
    for row in rows:
        movie_id = row[0]
        title = row[1]
        cover = row[2]
        director = row[3]
        scriptwriter = row[4]
        actor = row[5]
        category = row[6]
        country = row[7]
        language = row[8]
        release_date_str = row[9]
        duration_str = row[10]
        profile = row[11]
        rating_value = row[12]
        rating_people = row[13]
        star5 = row[14].replace("%", "")
        star4 = row[15].replace("%", "")
        star3 = row[16].replace("%", "")
        star2 = row[17].replace("%", "")
        star1 = row[18].replace("%", "")
        origin_url = row[19]

        # 处理分类
        categories = category.split("/")
        category_models = []
        for cate in categories:
            category_model, _ = MovieCategory.objects.get_or_create(name=cate.strip())
            category_models.append(category_model)

        # 处理国家
        countries = country.split("/")
        country_models = []
        for cou in countries:
            country_model, _ = MovieCountry.objects.get_or_create(name=cou)
            country_models.append(country_model)

        # 处理语言
        languages = language.split("/")
        language_models = []
        for lan in languages:
            language_model, _ = MovieLanguage.objects.get_or_create(name=lan)
            language_models.append(language_model)

        # 处理上映
        release_date_tmp = release_date_str.split("/")[0].strip()
        release_date_result = re.search(r"(\d{4}-\d{2}-\d{2})", '2004-10-16(中国大陆)')
        release_date = None
        if release_date_result:
            release_date_tmp = release_date_result.group(1)
            release_date = datetime.strptime(release_date_tmp, "%Y-%m-%d")

        # 处理电影时长
        duration = 0
        try:
            re.search("\d+", duration_str).group()
        except AttributeError:
            pass
        rating_value = float(rating_value)

        rating_model = MovieRating.objects.create(
            value=rating_value, rating_people=rating_people or 0,
            star5=star5, star4=star4,
            star3=star3, star2=star2, star1=star1,
        )

        movie_model = Movie.objects.create(
            db_movie_id=movie_id,
            name=title, cover=cover, director=director,
            scriptwriter=scriptwriter, actor=actor,
            release_date_str=release_date_str,
            release_date=release_date,
            duration_str=duration_str, duration=duration,
            rating=rating_model, profile=profile,
            origin_url=origin_url
        )
        movie_model.countries.set(country_models)
        movie_model.languages.set(language_models)
        movie_model.categories.set(category_models)
        movie_model.save()
    return JsonResponse({"message":"success"})


def resave_comment(request):
    cursor.execute("select db_movie_id,username,rating,pub_date,content,avatar from movie_comment;")
    rows = cursor.fetchall()
    for row in rows:
        movie_id = row[0]
        username = row[1]
        rating = row[2]
        pub_date = row[3]
        content = row[4]
        avatar = row[5]

        try:
            movie = Movie.objects.get(db_movie_id=movie_id)
            MovieComment.objects.create(
                username=username,
                rating=rating,
                pub_date=pub_date,
                content=content,
                db_movie_id=movie_id,
                movie=movie,
                avatar=avatar
            )
        except Exception as e:
            print(e)
    return JsonResponse({"message":"success"})